
jQuery Bubble Popup v.2.3.1
http://maxvergelli.wordpress.com/jquery-bubble-popup/
Copyright (c) 2010 Max Vergelli


Description:
"jQuery Bubble Popup" is a plugin to display smart, animated & shadowed, "bubble" popups with few lines of code in jQuery.


Documentation:
Inside the folder "Documentation" you will find all information about the jQuery Bubble Popup plugin, 


Installation:
1) copy the content of the folder "Install" in the root of your website
2) in each page where you want to use the plugin, add the following <link> and <script> tags inside the tag <head>:

	<link href="jquery.bubblepopup.v2.3.1.css" rel="stylesheet" type="text/css" />
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
	<script src="jquery.bubblepopup.v2.3.1.min.js" type="text/javascript"></script>

