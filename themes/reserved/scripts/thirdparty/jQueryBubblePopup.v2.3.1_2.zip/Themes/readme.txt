
with the file "bubble-popup-themes.png" You can create your customized themes.